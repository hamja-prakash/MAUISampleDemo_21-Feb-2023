﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAUISampleDemo.ViewModels
{
    public class CompileBindingViewModel
    {
        public string TestText { get; } = "This is Compile Binding Demo"; 
    }
}
