using Microsoft.Maui.Controls;

namespace MAUISampleDemo.View;

public partial class FlyoutDemo : FlyoutPage
{
	public FlyoutDemo()
	{
		InitializeComponent();
	}
}