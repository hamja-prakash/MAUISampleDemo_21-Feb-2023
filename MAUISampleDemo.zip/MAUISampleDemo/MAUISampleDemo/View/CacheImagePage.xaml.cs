namespace MAUISampleDemo.View;

public partial class CacheImagePage : ContentPage
{
	public CacheImagePage()
	{
		InitializeComponent();
	}
}