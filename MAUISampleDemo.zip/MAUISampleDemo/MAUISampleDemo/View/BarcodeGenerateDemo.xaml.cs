namespace MAUISampleDemo.View;

public partial class BarcodeGenerateDemo : ContentPage
{
	public BarcodeGenerateDemo()
	{
		InitializeComponent();
	}
}