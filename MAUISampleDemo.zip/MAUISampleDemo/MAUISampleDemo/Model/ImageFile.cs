﻿namespace MAUISampleDemo.Model
{
    public class ImageFile
    {
        public string byteBase64 { get; set; }
        public string ContentType { get; set; }
        public string FileName { get; set; }
    }
}
